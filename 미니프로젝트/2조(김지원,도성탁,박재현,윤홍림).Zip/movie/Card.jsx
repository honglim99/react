import React from "react";
import "./AboutMe.css";

function Card({ children }) {
  return <div className="card">{children}</div>;
}

export default Card;
