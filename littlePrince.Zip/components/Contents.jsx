import React from "react";
import Image from './Image';
import Content1 from './Content1';

function Contents() {
    return (
        <div className="Contents">
            <Image className="Image" />
            <Content1 className="Para1" />
        </div>
    )
}

export default Contents