import React from "react";

function Navbar() {
    return (
        <nav className="Menu">
            <a href="http://www.naver.com">네이버</a> |
            <a href="http://www.google.com">구글</a> |
            <a href="http://openai.com">오픈AI</a>
        </nav>
    )
}

export default Navbar